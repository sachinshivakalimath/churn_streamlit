import streamlit as st
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import time

from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from streamlit_option_menu import option_menu
from sklearn.preprocessing import MinMaxScaler
from utility import cat_imputer
from sklearn.model_selection import train_test_split
from pycaret.classification import *
from pycaret.classification import setup
from sklearn.metrics import confusion_matrix


def get_feature_importance(model):
    # Check if the model has attribute feature_importances_
    if hasattr(model, 'feature_importances_'):
        # Retrieve feature importances from the model
        importances = model.feature_importances_
        # Create a dictionary mapping feature names to importances
        feature_importance_dict = dict(zip(X_train.columns, importances))
        # Sort the dictionary by importance
        sorted_importance = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)
        return sorted_importance
    else:
        return None


def pycaret_classifier(df):
    df['Dependents'] = df['Dependents'].map({'Yes': 1, 'No': 0})

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(df.drop(columns=['Churn']), df['Churn'], test_size=0.2, random_state=42)


    col_names = X_train.columns

    # Convert the scaled arrays back to DataFrames
    X_train_df = pd.DataFrame(X_train, columns=col_names,index=X_train.index)
    X_test_df = pd.DataFrame(X_test, columns=col_names,index=X_test.index)

    train_data = X_train_df.join(y_train)
    test_data = X_test_df.join(y_test)
    train_data.reset_index(drop=True, inplace=True)
    test_data.reset_index(drop=True, inplace=True)

    # Setup PyCaret
    setup(data=train_data, target='Churn', session_id=123, categorical_features=['Dependents'],verbose=False)

    # Compare models and select the best one
    best_model = compare_models()

    # Get the model results dictionary
    model_results_dict = pull()

    # Train the best model
    final_model = finalize_model(best_model)
    # Get variable importance for the best model
    variable_importance = get_feature_importance(final_model)

    # Make predictions on the entire dataset (including unseen data)
    predictions = predict_model(final_model, data=test_data)
    predicted_labels = predictions['prediction_label']
    
    # prediction_scores = predictions['prediction_score']

    # Print predictions

    test_data['predicted_label'] = predicted_labels.astype(str)
    # test_data['prediction_scores'] = prediction_scores
    # test_data.to_csv('basic_prediction1.csv')

    # Extract true labels and predicted labels
    true_labels = test_data['Churn']
    predicted_labels = test_data['predicted_label']

    # Calculate confusion matrix
    conf_matrix = confusion_matrix(true_labels, predicted_labels)

    # Print the confusion matrix
    print("Confusion Matrix:")
    print(conf_matrix)
    
    return final_model, test_data, best_model,model_results_dict,conf_matrix, variable_importance


def main_page():
    st.title("AI FIRST COLLECTION")
    st.subheader("Generative AI App - AWS Bedrock \U0001F916 ")
   
    # Streamlit application layout setup
    st.subheader("Site Performance Analysis")
    col1, col2, col3 = st.columns(3)
    # Read data from Excel file
    try:
            df = pd.read_excel("EDA.xlsx")
            df1 = pd.read_excel("EDA2.xlsx")
            df1['Month'] = pd.to_datetime(df1['Month']).dt.strftime('%m-%y')

            # Check if the DataFrame is empty
            if df.empty:
                st.warning("The Excel file is empty. Please check the file and try again.")
            else:
                # Format the month to 'MM-YY'
                df['Month'] = pd.to_datetime(df['Month']).dt.strftime('%m-%y')

                # Sidebar Chart 1
                with col1:
                    fig, ax = plt.subplots()
                    ax.plot(df['Month'], df['RPC %'], color='blue', label='RPC %', marker='o')
                    ax.set_xlabel('Month')
                    ax.set_ylabel('RPC %')
                    ax.set_title('RPC % Over Months')
                    ax.legend()
                    st.pyplot(fig)
                   
                # Sidebar Chart 2
                with col2:
                    fig, ax = plt.subplots()
                    ax.plot(df['Month'], df['PTP %'], color='Green', label='PTP %', marker='o')
                    ax.set_xlabel('Month')
                    ax.set_ylabel('PTP %')
                    ax.set_title('PTP % Over Months')
                    ax.legend()
                    st.pyplot(fig)

                # Sidebar Chart 3
                with col3:
                    fig, ax1 = plt.subplots(figsize=(10, 7.9))
                    ax1.bar(df1['Month'], df1['Deliquency Rate- start of the month'], color='lightgreen', label='Deliquency Rate- SoM', width=0.5, align='center')
                    ax1.bar(df1['Month'], df1['Deliquency Rate- End of the Month'], color='darkorange', label='Deliquency Rate- EoM',width=0.2, align='center')
                    ax2 = ax1.twinx()
                    ax2.plot(df1['Month'], df1['Kept Rate'], color='blue', label='Kept Rate', marker='o')
                    ax1.set_xlabel('Month')
                    ax1.set_ylabel('Deliquency Rate%')
                    ax2.set_ylabel('Kept Rate%', rotation=270, va='bottom')
                    ax1.set_title('Deliquency Rate vs Kept Rate')
                    lines, labels = ax1.get_legend_handles_labels()
                    lines2, labels2 = ax2.get_legend_handles_labels()
                    ax2.legend(lines + lines2, labels + labels2)
                    st.pyplot(fig)


    except Exception as e:
        st.error(f"An error occurred while reading the file: {e}")


    st.write("")
    st.write("")

    st.subheader("KPIs of Latest Month vs MoM")
    col1, col2, col3, col4, col5, col6 = st.columns(6)
    col1.metric("$ Collected by Agent", "$ 9.9 Mn", "0.2%")
    col2.metric("Past Due Collected Count", "19.6 k", "-0.71%")
    col3.metric("Past Due Collected $", "$ 20.5 Mn", "11.3%")
    col4.metric("RPC Calls", "31 k", "-2.4%")
    col5.metric("PTP Calls", "9 k", "0.2%")
    col6.metric("ACH Count", "1,580", "-5.3%")   

    # st.subheader("Trend Analysis Over Months")
    col1, col2, col3, col4, col5, col6 = st.columns(6)
    # Read data from Excel file
    try:
            df = pd.read_excel("EDA.xlsx")
            df1 = pd.read_excel("EDA2.xlsx")
            df1['Month'] = pd.to_datetime(df1['Month']).dt.strftime('%m-%y')

            # Check if the DataFrame is empty
            if df.empty:
                st.warning("The Excel file is empty. Please check the file and try again.")
            else:
                # Format the month to 'MM-YY'
                df['Month'] = pd.to_datetime(df['Month']).dt.strftime('%m-%y')

                # Trend Chart 1
                with col1:
                    fig, ax = plt.subplots()
                    ax.fill_between(df['Month'], df['Collected by Agents'], color='pink', label='Collected by Agents', alpha=0.3)
                    ax.plot(df['Month'], df['Collected by Agents'], color='pink', label='Collected by Agents', marker='o')
                    # ax.set_xlabel('Month')
                    # ax.set_ylabel('Collected by Agents')
                    # ax.set_title('Collected by Agents over Month')
                    # ax.legend()
                    
                    for spine in ax.spines.values():
                        spine.set_visible(False)

                    ax.yaxis.set_ticks_position('none') 
                    ax.xaxis.set_ticks_position('none')
                    ax.tick_params(labelbottom=False, labelleft=False)
                    
                    st.pyplot(fig)


                # Trend Chart 2
                with col2:
                    fig, ax = plt.subplots()
                    ax.fill_between(df['Month'], df['Past Due Collected Count'], color='purple', label='Past Due Collected Count', alpha=0.1)
                    ax.plot(df['Month'], df['Past Due Collected Count'], color='purple', label='Past Due Collected Count', marker='o')
                    # ax.set_xlabel('Month')
                    # ax.set_ylabel('Past Due Collected Count')
                    # ax.set_title('Past Due Collected Count Over Months')
                    # ax.legend()
                    for spine in ax.spines.values():
                        spine.set_visible(False)

                    ax.yaxis.set_ticks_position('none') 
                    ax.xaxis.set_ticks_position('none')
                    ax.tick_params(labelbottom=False, labelleft=False)
                    
                    st.pyplot(fig)

                # Trend Chart 3
                with col3:
                    fig, ax = plt.subplots()
                    ax.fill_between(df['Month'], df['Past Due $ Collected'], color='orange', label='Past Due $ Collected', alpha=0.1)
                    ax.plot(df['Month'], df['Past Due $ Collected'], color='orange', label='Past Due $ Collected', marker='o')
                    # ax.set_xlabel('Month')
                    # ax.set_ylabel('Past Due $ Collected')
                    # ax.set_title('Past Due $ Collected Over Months')
                    # ax.legend()
                    for spine in ax.spines.values():
                        spine.set_visible(False)

                    ax.yaxis.set_ticks_position('none') 
                    ax.xaxis.set_ticks_position('none')
                    ax.tick_params(labelbottom=False, labelleft=False)
                    
                    st.pyplot(fig)

                # Trend Chart 4
                with col4:
                    fig, ax = plt.subplots()
                    ax.fill_between(df['Month'], df['RPC Calls'], color='brown', label='RPC Calls', alpha=0.1)
                    ax.plot(df['Month'], df['RPC Calls'], color='brown', label='Rpc Calls', marker='o')
                    # ax.set_xlabel('Month')
                    # ax.set_ylabel('RPC Calls')
                    # ax.set_title('RPC Calls Over Months')
                    # ax.legend()
                    for spine in ax.spines.values():
                        spine.set_visible(False)

                    ax.yaxis.set_ticks_position('none') 
                    ax.xaxis.set_ticks_position('none')
                    ax.tick_params(labelbottom=False, labelleft=False)
                    
                    st.pyplot(fig)

                # Trend Chart 5
                with col5:
                    fig, ax = plt.subplots()
                    ax.fill_between(df['Month'], df['PTP Calls'], color='blue', label='PTP Calls', alpha=0.1)
                    ax.plot(df['Month'], df['PTP Calls'], color='blue', label='PTP %', marker='o')
                    # ax.set_xlabel('Month')
                    # ax.set_ylabel('PTP Calls')
                    # ax.set_title('PTP % Over Months')
                    # ax.legend()
                    for spine in ax.spines.values():
                        spine.set_visible(False)

                    ax.yaxis.set_ticks_position('none') 
                    ax.xaxis.set_ticks_position('none')
                    ax.tick_params(labelbottom=False, labelleft=False)
                    st.pyplot(fig)

                # Trend Chart 6
                with col6:
                    fig, ax = plt.subplots()
                    ax.fill_between(df['Month'], df['ACH Count'], color='Green', label='ACH Count', alpha=0.1)
                    ax.plot(df['Month'], df['ACH Count'], color='Green', label='ACH Count', marker='o')
                    # ax.set_xlabel('Month')
                    # ax.set_ylabel('PTP %')
                    # ax.set_title('ACH Count Over Months')
                    # ax.legend()
                    for spine in ax.spines.values():
                        spine.set_visible(False)

                    ax.yaxis.set_ticks_position('none') 
                    ax.xaxis.set_ticks_position('none')
                    ax.tick_params(labelbottom=False, labelleft=False)

                    st.pyplot(fig)


    except Exception as e:
        st.error(f"An error occurred while reading the file: {e}")

def pre_interaction():
    st.title("AI FIRST COLLECTION")
    st.subheader("PRE INTERACTION MODELS")
    st.write("")
    st.write("")

    st.subheader("GEN AI Engine")

    # Add an upload button
    uploaded_file = st.file_uploader("Upload your data file", type=["csv", "xlsx"])

    if uploaded_file is not None:
        # Read the file
        df = pd.read_csv(uploaded_file)  # Adjust this according to the file type
        
        # Display the uploaded data
        st.write("Data Uploaded:")
        st.write(df.head())

        # Perform further analysis on the uploaded data
        
        # For example:
        st.write("Summary Statistics:")
        st.write(df.describe())

        st.write(pd.DataFrame({'Data Types': df.dtypes}))
        
        # Get the list of variables from the DataFrame
        variables = list(df.columns)

        # Define a dictionary mapping each variable to its possible data types
        data_types = {
            "Integer": "int",
            "Float": "float",
            "String": "str",
            "Date": "datetime",
        }

        # Multiselect widget to select variables and their data types
        selected_vars = st.multiselect("Select variables", variables)
         # Single select widget to select data type for all selected variables
        selected_type = st.selectbox("Select data type", ["Integer", "Float", "String", "Date"])

        # Display the selected variables and their data type
        if selected_vars and selected_type:
            # Create a dictionary to map selected variables to the specified data type
            var_to_dtype = {var: data_types[selected_type] for var in selected_vars}
            st.write("Selected Variables and Data Type:")
            # Create a DataFrame from the dictionary
            var_dtype_df = pd.DataFrame.from_dict(var_to_dtype, orient='index', columns=['Data Type'])
            st.write(var_dtype_df)

            # Update the data types of selected variables in the original DataFrame
            for var, dtype in var_to_dtype.items():
                df[var] = df[var].astype(dtype)
            
            
        # Filter numeric columns
        numeric_df = df.select_dtypes(include=['number'])

        # Calculate the correlation matrix
        correlation_matrix = numeric_df.corr()

        # Display the correlation matrix
        st.write("Correlation Matrix:")
        st.write(correlation_matrix)

        # Plot the heatmap
        fig, ax = plt.subplots(figsize=(4, 2))
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".1f", linewidths=.5, ax=ax)
        plt.title("Correlation Heatmap")
        plt.xticks(rotation=45)
        plt.yticks(rotation=0)
        st.pyplot(fig)

        progress_text = "Operation in progress. Please wait."
        my_bar = st.progress(1, text=progress_text)

        for percent_complete in range(100):
            time.sleep(0.1)
            my_bar.progress(percent_complete + 1, text=progress_text)
        time.sleep(1)
        my_bar.empty()

        final_model, test_data, best_model, model_results_dict, conf_matrix,variable_importance = pycaret_classifier(df)
        # st.write(final_model)
        st.write(test_data.head())
        st.write(best_model)
        st.table(model_results_dict.drop(["AUC"],axis = 1))
        st.write(variable_importance)

        # Plot confusion matrix
        fig, ax = plt.subplots(figsize=(2, 1))
        disp = ConfusionMatrixDisplay(confusion_matrix=conf_matrix, display_labels=['Not Churn', 'Churn'])
        disp.plot(cmap=plt.cm.Blues, ax=ax , values_format='d')

        plt.grid(False)

        # Adjust font size of tick labels
        ax.tick_params(axis='both', which='major', labelsize=3)
        
        plt.title('Confusion Matrix', fontsize=3) 
        plt.xlabel('Predicted Label', fontsize=3)
        plt.ylabel('True Label', fontsize=3) 

        # Display the confusion matrix plot in Streamlit
        st.pyplot(fig)

        
def optimization():
    st.title("AI FIRST COLLECTION")
    st.subheader("INTERATION OPTIMIZATION MODELS")

def opex():
    st.title("AI FIRST COLLECTION")
    st.subheader("OPERATIONAL EFFICIENCY & AUTOMATION MODELS")

def reten():
    st.title("AI FIRST COLLECTION")
    st.subheader("CUSTOMER RETENTION & LOYALTY MODELS")

def compl():
    st.title("AI FIRST COLLECTION")
    st.subheader("COMPLIANCE & RISK MANAGEMENT MODELS")


def app():
    st.set_page_config(page_title="AI FIRST COLLECTION",page_icon="https://www.logo.wine/a/logo/Genpact/Genpact-Logo.wine.svg",layout='wide', initial_sidebar_state='expanded')
    with open('style.css') as f:
            st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)
            st.sidebar.image('genpact.png', width = 5, caption='', use_column_width=True)
            st.sidebar.header('Cora Interaction Optimizer App `ver 1`')
            st.sidebar.markdown('Rapid Prototype @CXMAnalytics ')
            st.sidebar.markdown('''---''')

            # page = st.sidebar.radio("Navigate", ('Home', 'Run Gen AI', 'Sentiment & Intent Analysis', 'Gen AI Agent Assit','Gen AI Agent Coach','Learning & Best Practices'))


            with st.sidebar:
                # Define your custom inline CSS
                custom_css = """
                <style>
                    /* Attempt to target sidebar text */
                    .sidebar .sidebar-content {
                        font-size: 1px;  /* Adjust the font size as needed */
                    }

                    /* Target navigation items in the sidebar */
                    .sidebar .sidebar-content .nav-item {
                        font-weight: 100;
                    }
                </style>
                """  

                # with open('style.css') as f:
                # st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)
                st.markdown(custom_css, unsafe_allow_html=True)
                page = option_menu("Menu", ["Home", "Pre-Interaction", "Optimization", 
                                        "Opex","Retention & Loyalty","Compliance & Risk"], 
                                    icons=["house", "play-circle","graph-up","robot", "gear","book"], 
                                    menu_icon="cast", default_index=0)

            # Page routing
            if page == 'Home':
                main_page()
            elif page == 'Pre-Interaction':
                pre_interaction()
            elif page == 'Optimization':
                optimization()
            elif page == 'Opex':
                opex()
            elif page == 'Retention & Loyalty':
                reten()
            elif page == 'Compliance & Risk':
                compl()

            # CSS to inject contained in a string
            hide_table_row_index = """
                        <style>
                        thead tr th:first-child {display:none}
                        tbody th {display:none}
                        </style>
                        """

            # Inject CSS with Markdown
            st.markdown(hide_table_row_index, unsafe_allow_html=True)

if __name__ == "__main__":
        app() 