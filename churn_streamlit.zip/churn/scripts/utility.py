def cat_imputer(df, cat_vars, strategy):
    """
    Imputes missing values in numeric columns of a DataFrame based on the specified strategy.

    Parameters:
    df (pandas.DataFrame): Input DataFrame.
    num_vars (list): List of numeric columns to impute.
    strategy (str): Imputation strategy. Can be 'mean', 'median', or 'mode'.

    Returns:
    pandas.DataFrame: DataFrame with missing values imputed based on the specified strategy.
    """
    if strategy not in ["mode"]:
        raise ValueError("Invalid strategy. Supported strategies are 'mode'.")

    imputed_df = df.copy()

    for column in cat_vars:
        if df[column].dtype == 'object' and df[column].isnull().any():
            imputed_value = df[column].mode().iloc[0]  # Mode can return multiple values, so we take the first one
        imputed_df[column].fillna(imputed_value, inplace=True)

    return imputed_df