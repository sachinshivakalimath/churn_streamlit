import pandas as pd
import numpy as np

from sklearn.preprocessing import MinMaxScaler
from utility import cat_imputer
from sklearn.model_selection import train_test_split
from pycaret.classification import *
from pycaret.classification import setup

dsn = pd.read_csv("D:/ai_first/churn/data/c_data.csv")

dsn_head = dsn.head()

dsn_variable_list = dsn.dtypes

def categorize_variables(df):
    """
    Categorizes variables in a DataFrame into categorical and numeric.

    Parameters:
    df (pandas.DataFrame): Input DataFrame.

    Returns:
    tuple: A tuple containing two lists: categorical variables and numeric variables.
    """
    categorical_vars = []
    numeric_vars = []

    for column in df.columns:
        if df[column].dtype == 'object':
            categorical_vars.append(column)
        else:
            numeric_vars.append(column)
    
    return categorical_vars, numeric_vars

categorical_var, numeric_var = categorize_variables(dsn)

def find_missing_values_in_numeric_columns(df, subset_columns):
    """
    Finds missing values in numeric columns of a DataFrame within a subset of columns.

    Parameters:
    df (pandas.DataFrame): Input DataFrame.
    subset_columns (list): List of columns to check for missing values.

    Returns:
    pandas.DataFrame: A DataFrame containing column names and counts of missing values.
    """
    missing_values = []

    for column in subset_columns:
        if df[column].dtype != 'object':
            missing_count = df[column].isnull().sum()
            print(f"Column: {column}, Missing Count: {missing_count}")
            if missing_count > 0:
                missing_values.append((column, missing_count))

    return pd.DataFrame(missing_values, columns=['Column', 'Missing_Count'])


numeric_var_missing_table = (find_missing_values_in_numeric_columns(dsn, numeric_var))

def find_missing_values_in_categorical_columns(df, subset_columns):
    """
    Finds missing values in numeric columns of a DataFrame within a subset of columns.

    Parameters:
    df (pandas.DataFrame): Input DataFrame.
    subset_columns (list): List of columns to check for missing values.

    Returns:
    pandas.DataFrame: A DataFrame containing column names and counts of missing values.
    """
    missing_values = []

    for column in subset_columns:
        if df[column].dtype == 'object':
            missing_count = df[column].isnull().sum()
            print(f"Column: {column}, Missing Count: {missing_count}")
            if missing_count > 0:
                missing_values.append((column, missing_count))

    return pd.DataFrame(missing_values, columns=['Column', 'Missing_Count'])

categorical_var_missing_table = (find_missing_values_in_categorical_columns(dsn, categorical_var))

num_impute = ["mean","median"]
cat_impute = ["mode"]

def num_imputer(df, num_vars, strategy):
    """
    Imputes missing values in numeric columns of a DataFrame based on the specified strategy.

    Parameters:
    df (pandas.DataFrame): Input DataFrame.
    num_vars (list): List of numeric columns to impute.
    strategy (str): Imputation strategy. Can be 'mean', 'median', or 'mode'.

    Returns:
    pandas.DataFrame: DataFrame with missing values imputed based on the specified strategy.
    """
    if strategy not in ['mean', 'median']:
        raise ValueError("Invalid strategy. Supported strategies are 'mean', 'median'.")

    imputed_df = df.copy()

    for column in num_vars:
        if df[column].dtype != 'object' and df[column].isnull().any():
            if strategy == 'mean':
                imputed_value = df[column].mean()
            elif strategy == 'median':
                imputed_value = df[column].median()
            else:  # mode
                imputed_value = df[column].mode().iloc[0]  # Mode can return multiple values, so we take the first one
            imputed_df[column].fillna(imputed_value, inplace=True)
            
    return imputed_df

imputed_numeric_dsn = (num_imputer(dsn,numeric_var,"mean"))

def cat_imputer(df, cat_vars, strategy):
    """
    Imputes missing values in categorical columns of a DataFrame based on the specified strategy.

    Parameters:
    df (pandas.DataFrame): Input DataFrame.
    cat_vars (list): List of categorical columns to impute.
    strategy (str): Imputation strategy. Currently only supports 'mode'.

    Returns:
    pandas.DataFrame: DataFrame with missing values imputed based on the specified strategy.
    """
    if strategy != "mode":
        raise ValueError("Invalid strategy. Supported strategies are 'mode'.")

    imputed_df = df.copy()

    for column in cat_vars:
        if df[column].dtype == 'object' and df[column].isnull().any():
            imputed_value = df[column].mode().iloc[0]  # Mode can return multiple values, so we take the first one
            imputed_df[column].fillna(imputed_value, inplace=True)

    return imputed_df

imputed_dsn = cat_imputer(imputed_numeric_dsn, categorical_var, "mode")

def detect_outliers(df, numeric_vars, percentile=90):
    outliers = pd.DataFrame(columns=['Index', 'Variable', 'Outlier_Value'])
    
    for var in numeric_vars:
        # Calculate the specified percentile
        threshold = df[var].quantile(percentile / 100)
        
        # Find outliers based on the specified percentile
        var_outliers = df[df[var] > threshold][var]
        
        if not var_outliers.empty:
            var_outliers_df = pd.DataFrame({'Index': var_outliers.index,
                                            'Variable': var,
                                            'Outlier_Value': var_outliers.values})
            outliers = pd.concat([outliers, var_outliers_df], ignore_index=True)
        
    return outliers

def detect_and_replace_outliers(df, numeric_vars, percentile=90):
    modified_df = df.copy()
    has_outliers = True
    
    while has_outliers:
        outliers = pd.DataFrame(columns=['Index', 'Variable', 'Outlier_Value'])
        has_outliers = False
        
        for var in numeric_vars:
            # Calculate the specified percentile
            threshold = modified_df[var].quantile(percentile / 100)
            
            # Find outliers based on the specified percentile
            var_outliers = modified_df[modified_df[var] > threshold][var]
            
            if not var_outliers.empty:
                has_outliers = True
                # Replace outliers with the median value
                median_value = modified_df[var].median()
                modified_df.loc[var_outliers.index, var] = median_value
                
                # Store information about outliers
                var_outliers_df = pd.DataFrame({'Index': var_outliers.index,
                                                'Variable': var,
                                                'Outlier_Value': var_outliers.values})
                outliers = pd.concat([outliers, var_outliers_df], ignore_index=True)
                
        if not outliers.empty:
            print("Replaced outliers with median values.")
            print(outliers)
            
    return modified_df


clean_dsn = detect_and_replace_outliers(imputed_dsn, numeric_var,percentile=99)

#one hot encoding
encoded_dsn = pd.get_dummies(clean_dsn, columns=categorical_var, drop_first=True)

# Assuming df is your DataFrame and target_column is the column you want to predict
X = encoded_dsn.drop(columns=["Churn"])
y = encoded_dsn["Churn"]

# Split the data into training and testing sets (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

y_train = y_train.astype(str)
y_test = y_test.astype(str)

col_names = X_train.columns

# Initialize the MinMaxScaler
scaler = MinMaxScaler()

# Fit the scaler on the training data
scaler.fit(X_train)

# Transform both the training and test data
X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Convert the scaled arrays back to DataFrames
X_train_scaled = pd.DataFrame(X_train_scaled, columns=col_names,index=X_train.index)
X_test_scaled_df = pd.DataFrame(X_test_scaled, columns=col_names,index=X_test.index)

train_data = X_train_scaled.join(y_train)
test_data = X_test_scaled_df.join(y_test)

# # Reset indices of train_data and test_data
# train_data.reset_index(drop=True, inplace=True)
# test_data.reset_index(drop=True, inplace=True)

test_data.to_csv('test_data.csv')

setup(data=train_data, target='Churn', test_data=test_data, session_id=123)

best_model = compare_models()

model_metrics = pull()

# # Sort the model_metrics DataFrame by Accuracy in descending order
sorted_model_metrics = model_metrics.sort_values(by='Accuracy', ascending=False)

# # Get the name of the best model (the first row after sorting)
best_model_name = sorted_model_metrics.iloc[0]['Model']

print("Best model based on accuracy:", best_model_name)

# # Creating the model
model = create_model(best_model)

# # Tuning the model
tuned_model = tune_model(model)

# # Evaluating the model
evaluate_model(tuned_model)

final_model = finalize_model(tuned_model)
save_model(final_model, 'final_model')

pred_test = final_model.predict(X_test_scaled_df)

test_data['Pred_level'] = pred_test

test_data.to_csv("predicted.csv")

