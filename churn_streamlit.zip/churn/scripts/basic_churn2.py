import pandas as pd
from sklearn.model_selection import train_test_split
from pycaret.classification import *
from sklearn.metrics import confusion_matrix
# import matplotlib.pyplot as plt
# from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

# Load the dataset
df = pd.read_csv("D:/ai_first/churn/data/c_data.csv")

# Map 'Yes' and 'No' to 1 and 0 for the 'Dependents' column
df['Dependents'] = df['Dependents'].map({'Yes': 1, 'No': 0})

##################################
# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(df.drop(columns=['Churn']), df['Churn'], test_size=0.2, random_state=42)

col_names = X_train.columns

# Convert the scaled arrays back to DataFrames
X_train_df = pd.DataFrame(X_train, columns=col_names,index=X_train.index)
X_test_df = pd.DataFrame(X_test, columns=col_names,index=X_test.index)

train_data = X_train_df.join(y_train)
test_data = X_test_df.join(y_test)
train_data.reset_index(drop=True, inplace=True)
test_data.reset_index(drop=True, inplace=True)

# Setup PyCaret
setup(data=train_data, target='Churn', session_id=123, categorical_features=['Dependents'])

# Compare models and select the best one
best_model = compare_models()

# Train the best model
final_model = finalize_model(best_model)

# Make predictions on the entire dataset (including unseen data)
predictions = predict_model(final_model, data=test_data)
print("@@@@@@@@@",predictions)


predicted_labels = predictions['prediction_label']
# prediction_scores = predictions['prediction_score']

# Print predictions

test_data['predicted_label'] = predicted_labels
# test_data['prediction_scores'] = prediction_scores
# test_data.to_csv('basic_prediction1.csv')

# Extract true labels and predicted labels
true_labels = test_data['Churn']
predicted_labels = test_data['predicted_label']

# Calculate confusion matrix
conf_matrix = confusion_matrix(true_labels, predicted_labels)

# Print the confusion matrix
print("Confusion Matrix:")
print(conf_matrix)

# # Plot confusion matrix
# disp = ConfusionMatrixDisplay(confusion_matrix=conf_matrix, display_labels=['Not Churn', 'Churn'])
# disp.plot(cmap=plt.cm.Blues)
# plt.title('Confusion Matrix')
# plt.xlabel('Predicted Label')
# plt.ylabel('True Label')
# plt.show()